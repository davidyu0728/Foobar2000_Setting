/*
* SACD Decoder plugin
* Copyright(c) 2011-2018 Maxim V.Anisiutkin <maxim.anisiutkin@gmail.com>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with FFmpeg; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110 - 1301 USA
*/

#include "pthread.h"

int pthread_create(pthread_t* thread, const pthread_attr_t* attr, void* (*start_routine) (void*), void* arg) {
	*thread = CreateThread(NULL, 0, reinterpret_cast<LPTHREAD_START_ROUTINE>(start_routine), reinterpret_cast<LPVOID>(arg), 0, NULL);
	return (*thread != NULL) ? 0 : -1;
}

int pthread_cancel(pthread_t thread) {
	return 0;
}

int pthread_join(pthread_t thread, void** retval) {
	if (WaitForSingleObject(thread, 100) == WAIT_TIMEOUT) {
		TerminateThread(thread, 0);
	}
	return (CloseHandle(thread) != FALSE) ? 0 : -1;
}