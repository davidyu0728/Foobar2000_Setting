/*
* SACD Decoder plugin
* Copyright (c) 2011-2019 Maxim V.Anisiutkin <maxim.anisiutkin@gmail.com>
*
* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 2.1 of the License, or (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public
* License along with FFmpeg; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
*/

#ifndef _SACD_METABASE_H_INCLUDED
#define _SACD_METABASE_H_INCLUDED

#include "sacd_config.h"
#include "sacd_disc.h"

#include <atlcomcli.h>
#import <msxml6.dll>

using CXML_Document    = MSXML2::DOMDocument60;
using IXML_DocumentPtr = MSXML2::IXMLDOMDocumentPtr;
using IXML_NodePtr     = MSXML2::IXMLDOMNodePtr;

constexpr char* TAG_ROOT       = "root";
constexpr char* TAG_STORE      = "store";
constexpr char* TAG_TRACK      = "track";
constexpr char* TAG_INFO       = "info";
constexpr char* TAG_META       = "meta";
constexpr char* TAG_REPLAYGAIN = "replaygain";

constexpr char* ATT_ID      = "id";
constexpr char* ATT_NAME    = "name";
constexpr char* ATT_TYPE    = "type";
constexpr char* ATT_VALUE   = "value";
constexpr char* ATT_VALSEP  = ";";
constexpr char* ATT_VERSION = "version";

constexpr char* METABASE_CATALOG = "sacd_metabase";
constexpr char* METABASE_VERSION = "1.1";

class sacd_metabase_t {
	abort_callback_impl media_abort;
	string8             store_id;
	string8             store_path;
	CComVariant         xmlfile;
	IXML_DocumentPtr    xmldoc;
	bool                initialized;
	bool                modified;
public:
	sacd_metabase_t(sacd_disc_t* p_disc, const char* p_metafile);
	~sacd_metabase_t();
	bool get_track_info(t_uint32 track_number, file_info& info);
	bool set_track_info(t_uint32 track_number, const file_info& info, bool is_linked = false);
	bool commit();
private:
	bool init_xmldoc(const char* store_type);
	IXML_NodePtr get_track_node(t_uint32 track_number);
	IXML_NodePtr new_track_node(t_uint32 track_number);
	void delete_track_tags(IXML_NodePtr node_track, const char* tag_type, bool is_linked);
	void insert_track_tag(IXML_NodePtr node_track, const char* tag_type, const char* tag_name, const char* tag_value);
};

#endif
